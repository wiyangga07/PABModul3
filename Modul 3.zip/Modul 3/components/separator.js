import { View } from "react-native";

const Separator = (props) => {
    return <View style={{ height: props.height }}></View>
};

export default Separator;